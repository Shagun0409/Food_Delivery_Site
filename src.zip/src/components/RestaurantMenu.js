
import Shimmer from "./Shimmer";
import { useParams } from "react-router-dom";
import useRestauarantMenu from "../utils/useRestaurantMenu";
const RestaurantMenu = () => {

const { resId } = useParams();
  const resInfo = useRestauarantMenu(resId);

  const {
    name,
    cuisines,
    costForTwoMessage,
    cloudinaryImageId,
    avgRating,
    // sla: { deliveryTime },

  }=resInfo?.cards[2]?.card?.card?.info || {};

  const itemCards = resInfo?.cards[4]?.groupedCard?.cardGroupMap?.REGULAR?.cards[2]?.card?.card?.itemCards || [];
  

  if(!resInfo) {
    return <Shimmer/>;
  }

  return (
    <div className="menu">
      <h1>{name}</h1>
      <p>
        {cuisines.join(",")}-{costForTwoMessage}
      </p>
    

      <h3>{avgRating} stars</h3>
      {/* <h3>{deliveryTime} minutes</h3> */}
      <h2>Menu</h2>
      <ul>
        {itemCards.map(item =>
          <li key={item.card.info.id} >{item.card.info.name} -  Rs. {(item.card.info.price)/100 || (item.card.info.
defaultPrice)/100}/-</li>
         )}
        {/* <li>{itemCards[0].card.info.name}</li>
        <li>{itemCards[1].card.info.name}</li>
        <li>{itemCards[2].card.info.name}</li>
        <li>{itemCards[3].card.info.name}</li>
        <li>{itemCards[4].card.info.name}</li>
        <li>{itemCards[5].card.info.name}</li> */}
      </ul>
    </div>
  );
};
export default RestaurantMenu;