import { useEffect, useState } from "react";
import { MENU_URL } from "./constants";

const useRestaurantMenu = (resId) => {

  const [resinfo, setResInfo] = useState(null);
  
  useEffect(() => {
    fetchMenu();
  }, []);
    
  const fetchMenu = async () => {
    const data = await fetch(MENU_URL + resId);
        console.log("Fetch Menu URL2:", data);

    console.log("Fetch Menu URL:", MENU_URL + resId);


 try {
      const json = await (data ?? {}).json();
      console.log("Menu Fetch JSON Response:", json);
      setResInfo(json.data);
    } catch (parseError) {
      console.error("❌ Failed to parse JSON:", parseError);
    }

    // const json = await (data??{}).json();
    // console.log("Menu Fetch JSON Response:", json);
    // setResInfo(json.data);
  }
  return resinfo;
};

export default useRestaurantMenu;